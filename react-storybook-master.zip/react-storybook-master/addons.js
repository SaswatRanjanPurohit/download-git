// We are not using this file inside this project.
// But, this will be useful when a user is configuring it's own addons.
// Then he can import this file to add default set of addons.
require('./dist/server/addons');
