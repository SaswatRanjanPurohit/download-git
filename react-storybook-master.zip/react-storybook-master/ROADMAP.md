# Roadmap

### Short Term

* Addon API and addons
* A clear guide to hack React Storybook
* React Native Support

### Long Term

* Automatic story generation (and edge case detection) based on propTypes.
* Angular Support
* Vue Support
* UI addons (Add different panels like Action Logger)
