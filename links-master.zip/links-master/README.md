# Links
Links of code and slides related to talks in react bangalore meetup

* [Progressive web apps workshop](https://www.meetup.com/ReactJS-Bangalore/events/239248126/) [[code](https://github.com/prateekbh/preact-pwa-workshop)][[slides](https://github.com/ReactBangalore/links/blob/master/slides/pwa-workshop.pdf)]
