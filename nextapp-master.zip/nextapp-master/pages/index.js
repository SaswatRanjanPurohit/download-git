import React from 'react'
import Nav from '../components/Nav'

export default() => (
  <div>
    <h1>Its awesome working on next.js</h1>

  <Nav />
  </div>
)
