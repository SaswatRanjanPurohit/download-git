import React, { PureComponent } from 'react';
import classes from './App.css';

import withClass from '../hoc/withClass';
import Persons from "../components/Persons/Persons";
import Cockpit from "../components/Cockpit/Cockpit";
import Auxiliary from "../hoc/Auxiliary";

class App extends PureComponent {

  constructor(props) {
    super(props);
    console.log('[App/js] constructor ', props)
  }

  componentWillMount() {
    console.log('[App/js] Component will mount ')
  }

  componentDidMount() {
    console.log('[App/js] Component did mount ')
  }

  state = {
    persons: [
      { id: 'asdi8', name: 'Carb', age: 34 },
      { id: 'vsfadf', name: 'Mia', age: 8 },
      { id: 'qwdcas', name: 'Cecilia', age: 31 }
    ],
    showPersons: false,
    toggleClickCounter: 0
  };

  nameChangeHandler = (event, id) => {
    const personIndex = this.state.persons.findIndex((person) => {
      return person.id === id;
    });

    const person = {
      ...this.state.persons[personIndex]
    };

    person.name = event.target.value;

    const persons = [...this.state.persons];

    persons[personIndex] = person;

    this.setState({
      persons: persons
    })
  };

  togglePersonHandler = () => {
    let showState = this.state.showPersons;
    this.setState( (prevState, props) => {
      return {
        showPersons: !showState,
        toggleClickCounter: prevState.toggleClickCounter + 1
      }
    })
  };

  deletePersonHandler = (personIndex) => {
    const persons = [...this.state.persons];
    persons.splice(personIndex, 1);
    this.setState({persons: persons});
  };

  inputCounterHandler = (event) => {
    this.setState({ inputLength: event.target.value.length});
  };

  render() {

    console.log('[App/js] render method');

    let persons = null;

    if (this.state.showPersons) {
      persons = (
          <Persons
            persons={this.state.persons}
            clicked={this.deletePersonHandler}
            changed={this.nameChangeHandler}
          />
      );
    }

    return (
      <Auxiliary>
        <Cockpit
          appTitle={this.props.title}
          inputLength={this.state.persons.length}
          showPersons={this.state.showPersons}
          persons={this.state.persons}
          inputCounterHandler={this.inputCounterHandler}
          clicked={this.togglePersonHandler}
        />
        {persons}
      </Auxiliary>
    );
  }
}

export default withClass(App, classes.App);
