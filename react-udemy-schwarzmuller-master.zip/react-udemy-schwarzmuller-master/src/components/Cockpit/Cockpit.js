import React, { Fragment } from 'react';

import classes from './Cockpit.css';

const Cockpit = (props) => {

  let btnClass = [classes.Button];
  const assignedClasses = [];

  if (props.persons.length <= 2) {
    assignedClasses.push(classes.red);
  }

  if (props.persons.length <= 1) {
    assignedClasses.push(classes.bold);
  }

  if (props.showPersons) {
    btnClass.push(classes.Red);
  }

  return (
    <Fragment>
      <h1>{props.appTitle}</h1>
      <input type="text" onChange={props.inputCounterHandler}/>
      <p className={assignedClasses.join(' ')}>Total number of persons: {props.inputLength}</p>
      <button
        className={btnClass.join(' ')}
        onClick={props.clicked}
      >Toggle persons
      </button>
    </Fragment>
  )
};

export default Cockpit;