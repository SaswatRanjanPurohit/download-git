import React from 'react'

const Header = () =>
  <div className="header">
    <img src="logo.png" className="logo" />
  </div>

export default Header
