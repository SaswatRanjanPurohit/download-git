import React from 'react'

class Ticker extends React.Component {
  render() {
    return <div className="value">0</div>
  }
}

export default Ticker
