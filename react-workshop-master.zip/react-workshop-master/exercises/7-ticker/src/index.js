import React from 'react'
import ReactDOM from 'react-dom'
import Ticker from './ticker'

ReactDOM.render(<Ticker />, document.getElementById('root'))
