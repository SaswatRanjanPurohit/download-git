import React from 'react'
import ReactDOM from 'react-dom'
import App from './app'

ReactDOM.render(<App initialUser="facebook" />, document.getElementById('root'))
