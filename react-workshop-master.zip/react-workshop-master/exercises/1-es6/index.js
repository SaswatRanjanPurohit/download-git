/*
  Task 1: Replace var with let or const
  Task 2: Replace ES5 function with arrow function
*/

const greet = name => {
  let greeting = 'Hello ' + name
  return greeting
}

module.exports = greet
