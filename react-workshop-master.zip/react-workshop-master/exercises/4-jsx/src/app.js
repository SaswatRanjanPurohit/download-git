import React from 'react'

const App = () =>
  <div>
    {/* Add your content here */}
    Hello World!
    {/* Add your content here */}
  </div>

export default App
