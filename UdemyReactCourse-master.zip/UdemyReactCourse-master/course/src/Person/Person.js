import React from 'react';

class Person extends React.Component {
  render() {
    return (
      <p>I am {this.props.name} a {this.props.age} old Person</p>
    //  <p>{this.props.children}</p>
    );
  }
}

export default Person;
