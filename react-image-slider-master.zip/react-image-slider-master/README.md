# React Image Slider

## Live Demo
[https://sivadass.github.io/react-image-slider/](https://sivadass.github.io/react-image-slider/)

## Setup

Goto the project folder and install required dependencies:
```
npm install
```

And run Webpack to watch for code changes and generate **bundle.js**:
```
webpack
```

Now open **index.html** in your browser to view the live page.