# es2015

Donut Chart :https://codepen.io/priyankamalviya/pen/oWGrdq


ES6 Challenge 1 : http://codepen.io/priyankamalviya/full/mmqKxW/

Multiple Promises sequantially await - github API : https://codepen.io/priyankamalviya/pen/aWEwLZ?editors=1111

Multiple Promises concurrently await -github API : https://codepen.io/priyankamalviya/pen/Omzxpb

Await multiple promises using .all() : http://codepen.io/priyankamalviya/pen/GmxpGM

Map function using immutable.js library: https://codepen.io/priyankamalviya/pen/jmKbOB?editors=1011

ES6-document.forms: https://codepen.io/priyankamalviya/pen/QvPVyZ/

ES6_rest_operator_usage.js: https://codepen.io/priyankamalviya/pen/wdLWpW/

regex: regex1 : https://codepen.io/priyankamalviya/pen/WjVBWB

regex: regex III(find correct url): https://codepen.io/priyankamalviya/pen/weKKRx

regex: regex IV (character classes) : https://codepen.io/priyankamalviya/pen/BZjLRO

jQuery search from a list: https://codepen.io/priyankamalviya/pen/BZYJEd

Vanilla JS table filter : https://codepen.io/priyankamalviya/pen/zzWZEa

JS Generator - I : https://codepen.io/priyankamalviya/pen/XaKYaq

JS Generator - II: https://codepen.io/priyankamalviya/pen/xLEXwp

JS Generator - III : https://codepen.io/priyankamalviya/pen/xLRVNa

JS Generator - IV: https://codepen.io/priyankamalviya/pen/KvNYEj

Template Literals MiniProject - https://codepen.io/priyankamalviya/full/RQPqpa/
