/**
 * Created by priyankamalviya on 9/10/16.
 */
console.log("Hello from app.js");
