import React from 'react';

const Home = () => {
  return(
    <h2 className="text-center">
    Search by Github User Name Above.
    </h2>
  )
}


export default Home;
