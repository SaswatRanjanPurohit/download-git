# React Meeting Room

A simple web app to book meeting rooms inside an office.


## User Flow (to be developed)
![React Meeting Room](https://res.cloudinary.com/sivadass/image/upload/v1512291259/mockups/react-meeting-room-app-user-flow.jpg "User Flow")


## Live Demo 
[https://sivadass.github.io/react-meeting-room/](https://sivadass.github.io/react-meeting-room/)