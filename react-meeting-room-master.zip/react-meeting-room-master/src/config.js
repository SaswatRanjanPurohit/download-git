module.exports = {
  // Your google calender API key
  GOOGLE_API_KEY: 'AIzaSyBcSkZ15c9hK1Roe-zf5PI09mUaBWz5eak'
}
