Lesson 15 of React From The Ground Up - PokeDashboard PokeList
