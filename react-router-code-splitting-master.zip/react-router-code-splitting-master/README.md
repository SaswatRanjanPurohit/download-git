# react-router-code-splitting
Code splitting React JS SPA based on routes(react router dom) using Webpack
