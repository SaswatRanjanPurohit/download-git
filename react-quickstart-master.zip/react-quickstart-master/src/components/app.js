import React from 'react';

class App extends React.Component {
  render(){
    return(
      <div className="container">
        <h1><i className="material-icons">check_circle</i> Cool buddy!</h1>
        <p>Your project is booted successfully!</p>
      </div>
    )
  }
}

export default App;