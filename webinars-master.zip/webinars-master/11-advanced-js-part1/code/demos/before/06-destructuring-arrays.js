// Array destructuring - syntax
let arr = [1, 2, 3, 4];

// Step 1: Use arrau destructuring syntax to extract the first 2 item values into variables a and b. Log them.


// Skipping items when destructuring
// Step 2: Extract only first, third and fifth values from array [1,2,3,4,5]. Log them.


// Separate declaration and initialization for variables when destructuring
// Step 3: Separate out the declaration and destructring statements and repeat step 2.1


// Assigning default values when destructuring
// Step 4: Extract first, third, fifth and seventh values from array [1,2,3,4,5]. Provide a default value for few including the seventh one. Log them.
