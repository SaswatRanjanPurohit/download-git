import Form from "../components/Form";
import { connect } from "react-redux";

const FormContainer = connect()(Form);

export default FormContainer;
