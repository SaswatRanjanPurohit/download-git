# Basics of ES2015 - Webinar 2
* Arrow Functions
    - Expressions in RHS
    - Function body in RHS
    - Context of arrow functions (this)
    - Context of arrow functions within object methods
    - Context of arrow functions when used as event handlers
    - The arguments object of arrow functions (in extra-demos folder)
* Rest and spread operators
* The new object literal syntax
* Setting up prototype of an object
* Class declaration in ES2015