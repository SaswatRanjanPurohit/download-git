# References
1. [Exploring ES6, by Dr. Axel RauschMayer](http://exploringjs.com/es6/)
2. [Luke Hoban's GitHub repo on ES6 features](https://github.com/lukehoban/es6features#readme) - a version can also be found in the [Babel.js site](https://babeljs.io/learn-es2015/#ecmascript-2015-features-modules)
3. [The Modern JavaScript Tutorial](https://javascript.info/)