const x = require('./module');

console.log(x(10, 25));
