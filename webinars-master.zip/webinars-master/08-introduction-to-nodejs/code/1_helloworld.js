global
  .console
  .log('Hello Sreekanth!');

const myArray = ['one', 'two', 'three'];

console.log(__filename);
console.log(__dirname);
