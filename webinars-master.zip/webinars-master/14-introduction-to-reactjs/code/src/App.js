import React from "react";
import Form from "./Form";

class App extends React.Component {
  constructor() {
    super();
  }

  render() {
    return (
      <div>
        <Form />
      </div>
    );
  }
}

export default App;
