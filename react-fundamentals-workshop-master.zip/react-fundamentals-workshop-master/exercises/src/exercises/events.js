 import React from 'react'

 function Events() {
   return (
     <div>
       <p>Implement a simple signup form with 2 input fields to enter first name and last name.</p>
       <p>Clicking on a submit button should show first name and last name in alert</p>
       <hr />
     </div>
   )
 }

 export default Events
