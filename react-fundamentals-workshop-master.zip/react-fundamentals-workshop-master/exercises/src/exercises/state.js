import React from 'react'

function StateExamples() {
  return (
    <div>
      <p>Build a toggle button which toggles between Yes/No</p>
      <hr />
    </div>
  )
}

export default StateExamples
