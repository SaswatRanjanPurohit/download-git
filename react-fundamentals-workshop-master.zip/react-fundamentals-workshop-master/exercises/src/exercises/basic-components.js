import React from 'react'

function BasicComponents() {
  return (
    <div>
      <p>Implement a basic button with blue background and white text</p>
      <hr/>
      <p>Implement a button component with class syntax. Clicking on the button should show an alert with some text</p>
      <hr />
    </div>
  )
}

export default BasicComponents
