import  React from 'react'

export function LifeCycleMethods() {
  return (
    <div>
      <p>Fetch posts from <a href="https://jsonplaceholder.typicode.com/posts">here</a> and render it</p>
      <hr />
    </div>
  )
}

export default LifeCycleMethods
