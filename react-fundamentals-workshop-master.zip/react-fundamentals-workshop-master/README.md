# react-fundamentals-workshop
React fundamentals workshop

# Agenda
* create-react-app & JSX & components
* props, state, children
* Life cycle methods
* Events and forms
* Component composition and data flow
