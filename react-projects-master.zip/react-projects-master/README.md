Curating a collection of small react projects to gain more comfort with react JS and ES6.
