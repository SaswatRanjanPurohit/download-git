# Angular Interview Questions


## Coding Test

you just built hello world in angular2+ and may be you followed some video or blog and now you are brave enough to tell the interviewer that you know little bit angular2. 

### Expect the following questions


How would you implement a brush behavior using rxjs?
How would you implement a color picker with rxjs?



Answers link coming soon 