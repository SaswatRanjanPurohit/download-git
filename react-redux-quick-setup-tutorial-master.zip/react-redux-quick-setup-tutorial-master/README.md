# React Redux Quick Setup Tutorial
React and Redux quick setup guide for beginners
